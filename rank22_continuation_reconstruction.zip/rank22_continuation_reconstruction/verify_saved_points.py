#!/usr/bin/env python3
"""Independent full-tensor checks from saved factors, with extended arithmetic.
No historical decomposition at t=0.944 is available: historical checks here
are consistency checks of logged scalar distances, not a re-evaluation of
that missing point.
"""
from pathlib import Path
import json
import numpy as np
from scipy import linalg as la
from threadpoolctl import threadpool_limits
from continuation_reconstructed import read_factors,TensorMap,matmul_tensor,self_test


def tensor_loop(H,K,F,dtype=np.longdouble):
    H=np.asarray(H,dtype=dtype);K=np.asarray(K,dtype=dtype);F=np.asarray(F,dtype=dtype)
    out=np.zeros((H.shape[0],K.shape[0],F.shape[1]),dtype=dtype)
    for s in range(H.shape[1]):
        out += H[:,s,None,None]*K[None,:,s,None]*F[s,None,None,:]
    return out.ravel()


def norm(a):return np.sqrt(np.sum(a*a,dtype=np.longdouble))


def main():
    root=Path(__file__).resolve().parent
    with np.load(root/'new_run/system.npz') as d:
        target=d['target'];start=d['start_tensor'];P=d['P'];B=d['B'];S=d['S'];x0=d['x0']
    normM=norm(target.astype(np.longdouble))
    output={'unit_tests':self_test(),
            'projection_row_orthogonality_error':float(la.norm(P@P.T-np.eye(P.shape[0]))),
            'slice_basis_orthogonality_error':float(la.norm(B.T@B-np.eye(B.shape[1]))),
            'longdouble_precision_bits':np.finfo(np.longdouble).nmant,
            'saved_point_checks':{}}
    for name in ('best_t','best_rho','last'):
        with np.load(root/f'new_run/{name}.npz') as d:
            H,K,F,t,y=[d[k] for k in ('H','K','F','t','y')]
        value=tensor_loop(H,K,F)
        x=np.r_[H.T.ravel(),K.T.ravel(),F.ravel()]
        current=target.astype(np.longdouble)+np.longdouble(t)*(start.astype(np.longdouble)-target)
        exact=norm(value-target)
        output['saved_point_checks'][name]={
            't':float(t),'full_relative_residual_extended':float(exact/normM),
            'full_residual_to_current_target_extended':float(norm(value-current)),
            'projected_residual_absolute_extended':float(norm(P.astype(np.longdouble)@(value-current))),
            'slice_residual':float(la.norm(S@(x-x0))),
            'saved_coordinate_consistency':float(la.norm(x-(x0+B@y))),
            'weight':float(np.sum(norms:=np.prod([la.norm(A,axis=0) for A in (H,K,F.T)],axis=0))),
            'max_term_scale':float(norms.max())}
    # Check that the recovered starting tensor and an affine target path are
    # compatible with both independently logged historical scalar quantities.
    t=.9441412969489299;absolute=.06772477459562788;relative=.013033638947864162
    r_current=.0034863337009904335;rho_current=.0006711478237121047
    to_start=.005256027358082398;start_to_M=float(la.norm(start-target))
    target_norm_from_log=r_current/rho_current
    affine_target_norm=float(la.norm(target+t*(start-target)))
    predicted_current_squared=(1-t)*absolute**2+t*to_start**2-t*(1-t)*start_to_M**2
    output['historical_scalar_consistency_only']={
        'exact_residual_denominator_from_log':absolute/relative,
        'matrix_multiplication_norm':float(normM),
        'affine_current_target_norm':affine_target_norm,
        'current_target_norm_from_log':target_norm_from_log,
        'current_target_norm_absolute_difference':abs(affine_target_norm-target_norm_from_log),
        'current_residual_from_logged_distances_and_recovered_start':predicted_current_squared**.5,
        'logged_current_residual':r_current,
        'does_not_identify_original_projection_or_slice':True}
    (root/'verification.json').write_text(json.dumps(output,indent=2))
    print(json.dumps(output,indent=2))

if __name__=='__main__':
    with threadpool_limits(limits=1):main()
