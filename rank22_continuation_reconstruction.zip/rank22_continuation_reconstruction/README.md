# Rango 22: nuova continuation documentata

Questo pacchetto NON contiene lo script originale di luglio. Contiene una
nuova implementazione, una nuova esecuzione e la verifica indipendente dei
suoi residui. Il valore storico t=0.9441412969 non va associato al nuovo codice.

## Origine dell'input

`rank22_input.csv` è il file `rank_22_decomposition - Sheet1.csv` allegato
alla mail di Sara del 16 luglio 2026, ore 17:43, oggetto `Re: Vettori u, v, w`.
Quel messaggio sostituisce espressamente gli allegati precedenti dello stesso
giorno. Il CSV contiene 22 righe per ciascuno dei fattori F, H e K, con nove
coordinate per riga. L'intestazione è in fondo: il parser la gestisce senza
eliminare il primo addendo. Non sono i checkpoint Laurent di rango 18,19,20.

L'input recuperato ha residuo relativo 0.0137734386315816. Il file non
documenta il collegamento fra questa versione dei coefficienti e il
checkpoint grezzo della tabella del manoscritto (rho circa 0.031): non
attribuire al nuovo script un raffinamento iniziale non eseguito.

## Cosa è recuperato e cosa è nuovo

- `historical_extract.txt`: resoconto fornito dall'utente dell'esperimento
  precedente, con t minimo circa 0.944 e residuo circa 0.0130.
- `continuation_reconstructed.py`: NUOVO script con proiezione gaussiana
  fissa e slice ortogonale determinata dalla SVD del Jacobiano iniziale.
  Queste scelte non sono state recuperate dal vecchio codice.
- `new_run/`: risultati effettivamente calcolati con questa implementazione.
- `verification.json`: controllo indipendente dei fattori salvati, più
  controlli di coerenza dei soli numeri storici. Questi ultimi non
  ricostruiscono il punto storico né identificano la sua proiezione.

## Metodo

Sia f(theta) il tensore rappresentato, vettorizzato in 729 coefficienti.
La curva obiettivo è b(t)=M3+t*(f(theta0)-M3), con t=1 all'inizio e t=0
al bersaglio esatto. Dai 594 parametri si passa a 550 coordinate mediante
una slice fissa normale alle 44 direzioni del nucleo del Jacobiano iniziale.
Una proiezione fissa P: R^729 -> R^550 seleziona il sistema seguito dalla
pseudo-arclength. P e la base della slice sono salvate in `system.npz`.

Il sistema proiettato viene risolto, ma i residui sul tensore COMPLETO
sono controllati separatamente. Zeri del sistema proiettato non sono
certificati di decomposizione del tensore completo. La scelta della
proiezione, della slice e del protocollo delimita il significato locale
dell'esperimento.

## Esecuzione

Dipendenze: Python 3, NumPy, SciPy, threadpoolctl. Versioni effettivamente
usate e hash SHA256 del CSV sono registrati in `new_run/metadata.json`.

```
python continuation_reconstructed.py --self-test
python continuation_reconstructed.py rank22_input.csv \
  --out replay --seed 12345 --ds 1e-4 --max-ds 0.02 \
  --max-steps 1500 --tol 1e-11 --post-turn-steps 30
python verify_saved_points.py
```

Una directory di output già esistente non viene sovrascritta.
La run consegnata è stata interrotta dal limite temporale dell'ambiente
al passo 444 e continuata dallo stesso punto con le medesime P e B:
`complete_interrupted_run.py` documenta questa ripresa. Non vi è stato
alcun nuovo campionamento né alcun cambiamento delle equazioni. La run
completa si arresta trenta passi dopo il primo cambio di segno della
componente t della tangente, al passo 655. Non è stata esplorata la
continuazione successiva a questo arresto.

## Risultati della NUOVA run

- Inizio: rho=0.013773438631581562, W=896.4663221029743.
- Minimo t campionato, passo 625: t=0.4101103931476439;
  rho=0.006532207831071326, W=2191.786851142729.
- In questo punto: residuo proiettato assoluto 1.4753e-13;
  residuo completo al target corrente 0.01728824197839298.
- Minima rho campionata, passo 626: 0.006532126138802844.
- Ultimo punto, passo 655: t=0.4179465731131197,
  rho=0.0066560752886633216.

Il target t=0 non è stato raggiunto nel segmento tracciato. Il residuo
completo inizialmente scende mentre il peso aumenta, ma una traccia finita
non dimostra divergenza né l'inesistenza di altre decomposizioni. La run
non produce nuovi upper/lower bound per il rango o il border rank.

I controlli mediante somma indipendente in `longdouble` (63 bit espliciti
di mantissa in questo ambiente) confermano le cifre rilevanti dei residui.
Non sono certificazioni mediante intervalli. Gli unit test controllano
il Jacobiano analitico, l'ordine row-major e un caso artificiale di rango 1.

## Uso nel manoscritto

`continuation_main_paragraph.tex` propone un NUOVO paragrafo dei risultati.
`continuation_methods.tex` propone la documentazione per l'appendice.
Sono sostituzioni basate sulla nuova run, NON integrazioni documentali
retroattive del vecchio valore 0.944. Decidere di usare questa run comporta
sostituire i vecchi numeri e rendere disponibili questi file supplementari.

Per la continuation storica, il log e l'input sono compatibili a precisione
numerica con la stessa interpolazione affine dei tensori, come mostrano
i controlli delle distanze in `verification.json`. Questa compatibilità
NON determina la proiezione e la slice originali e non riproduce il punto
storico: per quello occorrerebbe ancora il vecchio script o il salvataggio
del suo sistema.

## Riferimenti sul metodo numerico generale (non sulla run storica)

Predictor-corrector e pseudo-arclength: documentazione ufficiale
BifurcationKit, https://bifurcationkit.github.io/BifurcationKitDocs.jl/v0.3/PALC/ .
Sistemi lineari: documentazione ufficiale SciPy,
https://docs.scipy.org/doc/scipy/reference/generated/scipy.linalg.solve.html .
Il codice qui consegnato usa NumPy/SciPy, non BifurcationKit.
