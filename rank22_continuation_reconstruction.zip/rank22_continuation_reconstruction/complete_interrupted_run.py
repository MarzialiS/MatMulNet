#!/usr/bin/env python3
"""Complete this interrupted NEW run using its saved fixed system.

This script is specific to the delivered run: it requires that best_t.npz
coincide with the last trace row, because that was the last saved point at
the execution time limit. It does not reconstruct the historical run.
"""
from pathlib import Path
import csv,json,time,warnings
import numpy as np
from scipy import linalg as la
from threadpoolctl import threadpool_limits
from continuation_reconstructed import TensorMap,ProjectedSystem


def main():
    folder=Path(__file__).resolve().parent/'new_run'
    metadata=json.loads((folder/'metadata.json').read_text())
    with (folder/'trace.csv').open() as fh: rows=list(csv.DictReader(fh))
    def typed(row):
        return {k:(int(float(v)) if k in ['step','newton_iters'] else float(v)) for k,v in row.items()}
    last=typed(rows[-1]); q=metadata['model_dimensions']['projected_equations']
    sys0=ProjectedSystem.__new__(ProjectedSystem)
    sys0.model=TensorMap(9,22)
    with np.load(folder/'system.npz') as data:
        for k in ('x0','B','S','P','singular_values'):setattr(sys0,k,data[k])
        sys0.target=data['target'];sys0.f0=data['start_tensor']
    sys0.q=q;sys0.direction=sys0.f0-sys0.target;sys0.target_norm=float(la.norm(sys0.target))
    sys0.gt=-(sys0.P@sys0.direction)/sys0.target_norm
    with np.load(folder/'best_t.npz') as data:z=np.r_[data['y'],data['t']]
    assert abs(z[-1]-last['t'])<1e-15,(z[-1],last['t'])
    tau=sys0.tangent(z)
    assert abs(tau[-1]-last['tangent_t'])<1e-8
    best_t=typed(min(rows,key=lambda r:float(r['t'])))
    best_rho=typed(min(rows,key=lambda r:float(r['relative_full_residual_to_exact'])))
    ds=.02;turn_step=None;failures=0;status='max_steps';started=time.perf_counter()
    print('Resuming at',last['step'],'t',last['t'],flush=True)
    with (folder/'trace.csv').open('a',newline='') as fh:
        writer=csv.DictWriter(fh,fieldnames=list(last))
        for step in range(last['step']+1,1501):
            while True:
                pred=z+ds*tau
                nxt,it,corr=sys0.correct(pred,tau,1e-11,20)
                if nxt is not None and la.norm(nxt-pred)<=2*ds:
                    nxt_tau=sys0.tangent(nxt,tau);break
                ds*=.5;failures+=1
                if ds<1e-9:
                    status='step_below_min_step';nxt=None;break
            if nxt is None:break
            if turn_step is None and tau[-1]<0 and nxt_tau[-1]>=0:turn_step=step
            z,tau=nxt,nxt_tau
            row=sys0.diagnostics(z,step,ds,it,tau,corr)
            writer.writerow(row);fh.flush()
            if row['t']<best_t['t']:
                best_t=row.copy();sys0.save_point(folder/'best_t.npz',z)
            if row['relative_full_residual_to_exact']<best_rho['relative_full_residual_to_exact']:
                best_rho=row.copy();sys0.save_point(folder/'best_rho.npz',z)
            if step%20==0:print(step,row['t'],row['tangent_t'],row['relative_full_residual_to_exact'],flush=True)
            if z[-1]<=0:status='crossed_t_zero_no_certification';break
            if turn_step is not None and step>=turn_step+30:status='stopped_after_first_turn';break
            if it<=3:ds=min(.02,ds*1.25)
            elif it>=7:ds=max(1e-9,ds*.7)
    sys0.save_point(folder/'last.npz',z)
    summary=dict(status=status,first_turn_step=turn_step,resume_start_step=last['step'],
                 initial_phase='Execution time limit after step 444; resumed from saved last point with identical P and B.',
                 rejected_predictors_after_resume=failures,elapsed_seconds_after_resume=time.perf_counter()-started,
                 initial_relative_residual=float(la.norm(sys0.direction)/sys0.target_norm),
                 minimum_t_point=best_t,minimum_full_relative_residual_point=best_rho,last_point=row)
    (folder/'summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':
    warnings.filterwarnings('error',category=la.LinAlgWarning)
    with threadpool_limits(limits=1): main()
